@extends('user.includes.promoter-wallet') @section('content')
<!-- tap on top starts-->
<div class="tap-top">
  <i data-feather="chevrons-up"></i>
</div>
<!-- tap on tap ends-->
<!-- Loader starts-->
<div class="loader-wrapper">
  <div class="dot"></div>
  <div class="dot"></div>
  <div class="dot"></div>
  <div class="dot"></div>
  <div class="dot"></div>
</div>
<!-- Loader ends-->
<!-- page-wrapper Start-->
<div class="page-wrapper compact-wrapper" id="pageWrapper">
  <!-- Page Header Start-->
  <div class="page-header">
    <div class="header-wrapper row m-0">
      <div class="header-logo-wrapper col-auto p-0">
        <div class="toggle-sidebar">
          <i class="status_toggle middle sidebar-toggle" data-feather="grid"></i>
        </div>
        <div class="logo-header-main">
          <a href="#">Milliondox</a>
        </div>
      </div>
      <div class="left-header col horizontal-wrapper ps-0">
        <div class="left-menu-header">
          <h2> Vault </h2>
        </div>
      </div>
      <div class="nav-right col-1 pull-right right-header p-0">
        <ul class="nav-menus">
          <li>
            <div class="mode">
              <i class="fa fa-moon-o"></i>
            </div>
          </li>
          <li class="search">
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19.25 19.25L13.75 13.75M2.75 9.16667C2.75 10.0093 2.91597 10.8437 3.23844 11.6222C3.56091 12.4007 4.03356 13.1081 4.6294 13.7039C5.22524 14.2998 5.93261 14.7724 6.71111 15.0949C7.48962 15.4174 8.32402 15.5833 9.16667 15.5833C10.0093 15.5833 10.8437 15.4174 11.6222 15.0949C12.4007 14.7724 13.1081 14.2998 13.7039 13.7039C14.2998 13.1081 14.7724 12.4007 15.0949 11.6222C15.4174 10.8437 15.5833 10.0093 15.5833 9.16667C15.5833 8.32402 15.4174 7.48962 15.0949 6.71111C14.7724 5.93261 14.2998 5.22524 13.7039 4.6294C13.1081 4.03356 12.4007 3.56091 11.6222 3.23844C10.8437 2.91597 10.0093 2.75 9.16667 2.75C8.32402 2.75 7.48962 2.91597 6.71111 3.23844C5.93261 3.56091 5.22524 4.03356 4.6294 4.6294C4.03356 5.22524 3.56091 5.93261 3.23844 6.71111C2.91597 7.48962 2.75 8.32402 2.75 9.16667Z" stroke="#525252" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </li>
          <li class="setting_munal">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9.24922 22L8.84922 18.8C8.63255 18.7167 8.42855 18.6167 8.23722 18.5C8.04589 18.3833 7.85822 18.2583 7.67422 18.125L4.69922 19.375L1.94922 14.625L4.52422 12.675C4.50755 12.5583 4.49922 12.446 4.49922 12.338V11.663C4.49922 11.5543 4.50755 11.4417 4.52422 11.325L1.94922 9.375L4.69922 4.625L7.67422 5.875C7.85755 5.74167 8.04922 5.61667 8.24922 5.5C8.44922 5.38333 8.64922 5.28333 8.84922 5.2L9.24922 2H14.7492L15.1492 5.2C15.3659 5.28333 15.5702 5.38333 15.7622 5.5C15.9542 5.61667 16.1416 5.74167 16.3242 5.875L19.2992 4.625L22.0492 9.375L19.4742 11.325C19.4909 11.4417 19.4992 11.5543 19.4992 11.663V12.337C19.4992 12.4457 19.4826 12.5583 19.4492 12.675L22.0242 14.625L19.2742 19.375L16.3242 18.125C16.1409 18.2583 15.9492 18.3833 15.7492 18.5C15.5492 18.6167 15.3492 18.7167 15.1492 18.8L14.7492 22H9.24922ZM12.0492 15.5C13.0159 15.5 13.8409 15.1583 14.5242 14.475C15.2076 13.7917 15.5492 12.9667 15.5492 12C15.5492 11.0333 15.2076 10.2083 14.5242 9.525C13.8409 8.84167 13.0159 8.5 12.0492 8.5C11.0659 8.5 10.2366 8.84167 9.56122 9.525C8.88589 10.2083 8.54855 11.0333 8.54922 12C8.54922 12.9667 8.88689 13.7917 9.56222 14.475C10.2376 15.1583 11.0666 15.5 12.0492 15.5Z" fill="#525252" />
            </svg>
          </li>
          <li class="onhover-dropdown">
            <div class="notification-box">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M5.35737 2.01089C5.46244 1.8855 5.51415 1.72391 5.5014 1.56082C5.48866 1.39772 5.41248 1.24613 5.28922 1.13857C5.16596 1.03101 5.00544 0.976075 4.84212 0.985546C4.6788 0.995017 4.52571 1.06814 4.41571 1.18923L3.33904 2.42256C2.72852 3.1222 2.3834 4.0142 2.36404 4.94256L2.31654 7.20839C2.31484 7.29047 2.32933 7.37207 2.35917 7.44855C2.38901 7.52503 2.43363 7.59488 2.49046 7.65412C2.5473 7.71335 2.61525 7.76081 2.69043 7.79379C2.76561 7.82677 2.84655 7.84461 2.92862 7.84631C3.0107 7.84801 3.09231 7.83352 3.16878 7.80368C3.24526 7.77383 3.31511 7.72922 3.37435 7.67238C3.43358 7.61555 3.48105 7.5476 3.51402 7.47242C3.547 7.39724 3.56484 7.3163 3.56654 7.23423L3.61321 4.96923C3.62658 4.334 3.86285 3.72369 4.28071 3.24506L5.35737 2.01089Z" fill="#5790FF" />
                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.19664 6.41663C5.25261 5.52507 5.64624 4.68836 6.29741 4.07682C6.94858 3.46529 7.80834 3.1249 8.70164 3.12496H9.16581V2.49996C9.16581 2.27895 9.25361 2.06698 9.40989 1.9107C9.56617 1.75442 9.77813 1.66663 9.99914 1.66663C10.2202 1.66663 10.4321 1.75442 10.5884 1.9107C10.7447 2.06698 10.8325 2.27895 10.8325 2.49996V3.12496H11.2966C12.19 3.1249 13.0497 3.46529 13.7009 4.07682C14.352 4.68836 14.7457 5.52507 14.8016 6.41663L14.9858 9.36163C15.056 10.4845 15.433 11.5666 16.0758 12.49C16.2086 12.6808 16.2898 12.9029 16.3114 13.1344C16.333 13.3659 16.2943 13.5991 16.1991 13.8113C16.1038 14.0234 15.9553 14.2073 15.768 14.3451C15.5807 14.4829 15.3609 14.5698 15.13 14.5975L12.2908 14.9375V15.8333C12.2908 16.4411 12.0494 17.024 11.6196 17.4537C11.1898 17.8835 10.6069 18.125 9.99914 18.125C9.39136 18.125 8.80846 17.8835 8.37869 17.4537C7.94892 17.024 7.70748 16.4411 7.70748 15.8333V14.9375L4.86831 14.5966C4.63756 14.5689 4.4179 14.4819 4.23068 14.3442C4.04346 14.2065 3.89505 14.0227 3.79985 13.8107C3.70466 13.5986 3.66593 13.3656 3.68741 13.1342C3.7089 12.9028 3.78988 12.6808 3.92248 12.49C4.56523 11.5666 4.94225 10.4845 5.01248 9.36163L5.19664 6.41663ZM8.70164 4.37496C8.12629 4.37489 7.57254 4.5941 7.15313 4.98797C6.73372 5.38183 6.48018 5.92073 6.44414 6.49496L6.26081 9.43996C6.1761 10.7908 5.72241 12.0925 4.94914 13.2033C4.93953 13.2171 4.93366 13.2332 4.93209 13.2499C4.93052 13.2666 4.93331 13.2835 4.94019 13.2989C4.94707 13.3142 4.9578 13.3275 4.97134 13.3375C4.98489 13.3475 5.00078 13.3538 5.01748 13.3558L8.13164 13.73C9.37248 13.8783 10.6258 13.8783 11.8666 13.73L14.9808 13.3558C14.9975 13.3538 15.0134 13.3475 15.0269 13.3375C15.0405 13.3275 15.0512 13.3142 15.0581 13.2989C15.065 13.2835 15.0678 13.2666 15.0662 13.2499C15.0646 13.2332 15.0588 13.2171 15.0491 13.2033C14.2761 12.0924 13.8227 10.7907 13.7383 9.43996L13.5541 6.49496C13.5181 5.92073 13.2646 5.38183 12.8452 4.98797C12.4258 4.5941 11.872 4.37489 11.2966 4.37496H8.70164ZM9.99914 16.875C9.42414 16.875 8.95748 16.4083 8.95748 15.8333V15.2083H11.0408V15.8333C11.0408 16.4083 10.5741 16.875 9.99914 16.875Z" fill="#5790FF" />
                <path d="M14.7023 1.12921C14.5774 1.23819 14.501 1.39229 14.4897 1.55762C14.4785 1.72296 14.5333 1.88599 14.6423 2.01088L15.7189 3.24421C16.1367 3.72318 16.3727 4.3338 16.3856 4.96921L16.4331 7.23338C16.4365 7.39914 16.5057 7.55675 16.6253 7.67154C16.7449 7.78632 16.9053 7.84889 17.071 7.84546C17.2368 7.84203 17.3944 7.7729 17.5092 7.65327C17.624 7.53364 17.6865 7.3733 17.6831 7.20754L17.6356 4.94254C17.6162 4.01419 17.2711 3.12218 16.6606 2.42254L15.5839 1.18921C15.475 1.06437 15.3209 0.987915 15.1555 0.976663C14.9902 0.965412 14.8272 1.02028 14.7023 1.12921Z" fill="#5790FF" />
              </svg>
            </div>
            <ul class="notification-dropdown onhover-show-div">
              <li> ------ </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <!-- Page Header Ends-->
  <!-- Page Body Start-->
  <div class="page-body-wrapper">
    <!-- Page Sidebar Start--> @include('user/includes.client-sidebar')
    <!-- Page Sidebar Ends-->
    <div class="page-body">
      <!-- greeting -->
      <div class="mlb-menu-header container-fluid" style="display:none;">
        <h2>Vault </h2>
      </div>
      <!-- Container-fluid start-->
      <!-- <div class="bredcrum"><div class="container-fluid"><div class="row"><div class="col-sm-12"></div></div></div></div> -->
      <!-- Container-fluid start-->
      <div class="container-fluid">
      @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
        <div class="row">
          <div class="col-sm-12">
            <div class="welcome-volt">
              <div class="welome_volt_text">
                <h2>Welcome to the Vault</h2>
                <p>Store all your sensitive data securely here</p>                
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Container-fluid start-->
      <!-- Container-fluid start-->
      <div class="container-fluid">
        <div class="row raw_valut">
          <div class="col-sm-12">
            <div class="your_wallet welome_wallet">
            <div class="alert p-2 inpt_wrap">
@if (session('success'))
    <div class="alert alert-success" id="successMessage">
        {{ session('success') }}
    </div>
@endif

@if (session('error'))
    <div class="alert alert-danger" id="errorMessage">
        {{ session('error') }}
    </div>
@endif
</div>
              <!-- first step start -->
              <div class="welcome_volt_round_one" id="sfsdfsd"> 
              <form id="submitForm" action="{{ route('submitForm') }}" method="POST" enctype="multipart/form-data">
    @csrf
  
   
    
              <h2>Vault Login <span>
                  <svg width="40" height="32" viewBox="0 0 40 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M24 19C24.7956 19 25.5587 18.6839 26.1213 18.1213C26.6839 17.5587 27 16.7956 27 16C27 15.2044 26.6839 14.4413 26.1213 13.8787C25.5587 13.3161 24.7956 13 24 13C23.2044 13 22.4413 13.3161 21.8787 13.8787C21.3161 14.4413 21 15.2044 21 16C21 16.7956 21.3161 17.5587 21.8787 18.1213C22.4413 18.6839 23.2044 19 24 19ZM0 7.5C0 5.51088 0.790176 3.60322 2.1967 2.1967C3.60322 0.790176 5.51088 0 7.5 0H32.5C34.4891 0 36.3968 0.790176 37.8033 2.1967C39.2098 3.60322 40 5.51088 40 7.5V24.5C40 26.4891 39.2098 28.3968 37.8033 29.8033C36.3968 31.2098 34.4891 32 32.5 32H7.5C5.51088 32 3.60322 31.2098 2.1967 29.8033C0.790176 28.3968 0 26.4891 0 24.5V7.5ZM7.5 6C7.10218 6 6.72064 6.15804 6.43934 6.43934C6.15804 6.72064 6 7.10218 6 7.5V24.5C6 24.8978 6.15804 25.2794 6.43934 25.5607C6.72064 25.842 7.10218 26 7.5 26C7.89782 26 8.27936 25.842 8.56066 25.5607C8.84196 25.2794 9 24.8978 9 24.5V7.5C9 7.10218 8.84196 6.72064 8.56066 6.43934C8.27936 6.15804 7.89782 6 7.5 6ZM18.56 8.44C18.4227 8.29263 18.2571 8.17442 18.0731 8.09244C17.8891 8.01045 17.6905 7.96637 17.489 7.96282C17.2876 7.95926 17.0876 7.99631 16.9008 8.07175C16.714 8.1472 16.5444 8.25949 16.4019 8.40192C16.2595 8.54436 16.1472 8.71403 16.0718 8.9008C15.9963 9.08758 15.9593 9.28764 15.9628 9.48904C15.9664 9.69045 16.0105 9.88908 16.0924 10.0731C16.1744 10.2571 16.2926 10.4227 16.44 10.56L18.83 12.952C18.2847 13.875 17.998 14.9279 18 16C18 17.112 18.302 18.154 18.83 19.048L16.44 21.44C16.2926 21.5773 16.1744 21.7429 16.0924 21.9269C16.0105 22.1109 15.9664 22.3095 15.9628 22.511C15.9593 22.7124 15.9963 22.9124 16.0718 23.0992C16.1472 23.286 16.2595 23.4556 16.4019 23.5981C16.5444 23.7405 16.714 23.8528 16.9008 23.9282C17.0876 24.0037 17.2876 24.0407 17.489 24.0372C17.6905 24.0336 17.8891 23.9895 18.0731 23.9076C18.2571 23.8256 18.4227 23.7074 18.56 23.56L20.952 21.17C21.846 21.698 22.888 22 24 22C25.112 22 26.154 21.698 27.048 21.17L29.44 23.56C29.5773 23.7074 29.7429 23.8256 29.9269 23.9076C30.1109 23.9895 30.3095 24.0336 30.511 24.0372C30.7124 24.0407 30.9124 24.0037 31.0992 23.9282C31.286 23.8528 31.4556 23.7405 31.5981 23.5981C31.7405 23.4556 31.8528 23.286 31.9282 23.0992C32.0037 22.9124 32.0407 22.7124 32.0372 22.511C32.0336 22.3095 31.9895 22.1109 31.9076 21.9269C31.8256 21.7429 31.7074 21.5773 31.56 21.44L29.17 19.048C29.698 18.154 30 17.112 30 16C30 14.888 29.698 13.846 29.17 12.952L31.56 10.56C31.825 10.2757 31.9692 9.89956 31.9623 9.51096C31.9555 9.12235 31.7981 8.75158 31.5232 8.47676C31.2484 8.20193 30.8776 8.04451 30.489 8.03765C30.1004 8.03079 29.7243 8.17504 29.44 8.44L27.048 10.83C26.1249 10.2848 25.0721 9.99806 24 10C22.888 10 21.846 10.302 20.952 10.83L18.56 8.44Z" fill="#575757" />
                  </svg>
                </span>
              </h2>
              <div class="your_kkey">
        <p>Click me to upload Your Key File:</p>
        <input type="file" name="keyfile" id="keyfile" class="form-control">
    </div>
                <div class="botto_btn_nt">
                  <button type="submit"  class="btn btn-primary btn-block btn-square" style="border-radius:5px;">Upload Key<span>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.5 10.577V1.927L4.17 4.257L3.462 3.538L7 0L10.538 3.538L9.831 4.258L7.5 1.927V10.577H6.5ZM1.615 14C1.155 14 0.771 13.846 0.463 13.538C0.154333 13.2293 0 12.845 0 12.385V9.962H1V12.385C1 12.5383 1.064 12.6793 1.192 12.808C1.32067 12.936 1.46167 13 1.615 13H12.385C12.5383 13 12.6793 12.936 12.808 12.808C12.936 12.6793 13 12.5383 13 12.385V9.962H14V12.385C14 12.845 13.846 13.229 13.538 13.537C13.2293 13.8457 12.845 14 12.385 14H1.615Z" fill="white"/>
                </svg>
                    </span>
                  </button>
                  </div>

                  <div class="welcome_contact">
                    <span>Contact us at<a href="tel:+91 33 4888 880">+91 33 4888 880</a></span>
                    <span>or</span>
                    <span>Write to us at<a href="mailto:help@milliondox.com">help@milliondox.com</a></span>                    
                </div>        
</form>
                
             
</div>
              <!-- first step end -->

             

              <!-- third step start -->
              <div class="welcome_volt_round_third"  id="tbbbbb" style="display:none;">

              <div class="valut_enteries">
                <div class="hearder-entres">
                    <div class="volt_headd">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M15.9987 2.66675C12.3227 2.66675 9.33203 5.65741 9.33203 9.33341V13.3334H7.9987C7.29145 13.3334 6.61318 13.6144 6.11308 14.1145C5.61298 14.6146 5.33203 15.2928 5.33203 16.0001V26.6667C5.33203 27.374 5.61298 28.0523 6.11308 28.5524C6.61318 29.0525 7.29145 29.3334 7.9987 29.3334H23.9987C24.7059 29.3334 25.3842 29.0525 25.8843 28.5524C26.3844 28.0523 26.6654 27.374 26.6654 26.6667V16.0001C26.6654 15.2928 26.3844 14.6146 25.8843 14.1145C25.3842 13.6144 24.7059 13.3334 23.9987 13.3334H22.6654V9.33341C22.6654 5.65741 19.6747 2.66675 15.9987 2.66675ZM11.9987 9.33341C11.9987 7.12808 13.7934 5.33341 15.9987 5.33341C18.204 5.33341 19.9987 7.12808 19.9987 9.33341V13.3334H11.9987V9.33341ZM17.332 23.6307V26.6667H14.6654V23.6307C14.1992 23.3638 13.8249 22.9618 13.5918 22.4779C13.3587 21.9939 13.2777 21.4507 13.3596 20.9198C13.4415 20.3889 13.6823 19.8953 14.0504 19.504C14.4184 19.1127 14.8965 18.8422 15.4214 18.7281C15.8113 18.6419 16.2155 18.6443 16.6044 18.7351C16.9932 18.826 17.3567 19.0029 17.668 19.253C17.9793 19.503 18.2306 19.8197 18.4032 20.1798C18.5758 20.5399 18.6654 20.9341 18.6654 21.3334C18.6646 21.7997 18.5409 22.2576 18.3069 22.6609C18.0728 23.0643 17.7366 23.3988 17.332 23.6307Z" fill="#575757"/>
</svg>
<h2>Vault</h2>
</div>
<div class="search_nt">
<div class="svg_srch">
 <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.75 14.75L10.25 10.25M1.25 6.5C1.25 7.18944 1.3858 7.87213 1.64963 8.50909C1.91347 9.14605 2.30018 9.7248 2.78769 10.2123C3.2752 10.6998 3.85395 11.0865 4.49091 11.3504C5.12787 11.6142 5.81056 11.75 6.5 11.75C7.18944 11.75 7.87213 11.6142 8.50909 11.3504C9.14605 11.0865 9.7248 10.6998 10.2123 10.2123C10.6998 9.7248 11.0865 9.14605 11.3504 8.50909C11.6142 7.87213 11.75 7.18944 11.75 6.5C11.75 5.81056 11.6142 5.12787 11.3504 4.49091C11.0865 3.85395 10.6998 3.2752 10.2123 2.78769C9.7248 2.30018 9.14605 1.91347 8.50909 1.64963C7.87213 1.3858 7.18944 1.25 6.5 1.25C5.81056 1.25 5.12787 1.3858 4.49091 1.64963C3.85395 1.91347 3.2752 2.30018 2.78769 2.78769C2.30018 3.2752 1.91347 3.85395 1.64963 4.49091C1.3858 5.12787 1.25 5.81056 1.25 6.5Z" stroke="#BFBFBF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>
</div>
 <input type="search" class="" placeholder="Search for a template here" aria-controls="basic-1">
</div>
</div>
<div class="alert p-2 inpt_wrap">
@if (session('success'))
    <div class="alert alert-success" id="successMessage">
        {{ session('success') }}
    </div>
@endif

@if (session('error'))
    <div class="alert alert-danger" id="errorMessage">
        {{ session('error') }}
    </div>
@endif
</div>
<script>
    $(document).ready(function() {
        // Function to hide success message after 2 seconds
        setTimeout(function() {
            $('#successMessage').fadeOut('slow', function() {
                $(this).remove();
            });
        }, 2000);

        // Function to hide error message after 2 seconds
        setTimeout(function() {
            $('#errorMessage').fadeOut('slow', function() {
                $(this).remove();
            });
        }, 2000);
    });
</script>
<div class="entery_body table-responsive">
@if($documents->isNotEmpty())
<table class="table table-striped" id="refreshtb">
<thead>
  <tr>
    <th>File name</th>
    
    <th>Last modified</th>

    <th>Action</th>
  </tr>
  </thead>
  <tbody id="document-table-body">
  @foreach($documents as $document)
  <tr>
    <td>{{ $document->name }}</td>
  
    <td>{{ $document->created_at }}</td>
    <td>
  <a href="/documents/{{ $document->id }}/download"><span class="fa fa-download"></span></a>
                          </td>
                      </tr>
                  @endforeach         


      
     
    </tbody>
   

</table>
@else
<table class="table table-striped" id="refreshtb">
<thead>
  <tr>
    <th>File name</th>
    
    <th>Last modified</th>

    <th>Action</th>
  </tr>
  </thead>
  <tbody id="document-table-body">
  @foreach($documents as $document)
  <tr>
    <td>{{ $document->name }}</td>
  
    <td>{{ $document->created_at }}</td>
    <td>
  <a href="/documents/{{ $document->id }}/download"><i class="fas fa-download"></i></a>
</td>
                      </tr>
                  @endforeach         


      
     
    </tbody>
   

</table>
@endif
<table class="table table-striped" id="hidetb" style="display: none;">
<thead class="dispnone">
  <tr>
  <th>File name</th>
    
    <th>Last modified</th>

    <th>Action</th>
  </tr>
  </thead>
<tbody id="document-table-bodys" >
  <tr class="new_data_show">
                  <form id="anotherForm" action="{{ route('submitDocu') }}" method="POST" enctype="multipart/form-data">
      @csrf
    <td> <input type="file" name="anotherFile" id="anotherFile" class="form-control" required></td>
  
    <td> <input type="text" name="document_name" class="form-control" id="docu_name" placeholder="File Name" required></td>
    <td>
    <button type="submit" class="btn btn-primary"  id="hideform">Upload</button>
                          </td>
</form>
                      </tr>
  </tbody>
</table>
<div class="tabs_col_head">
    <button id="add_more">
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.41797 7.58341H2.91797V6.41675H6.41797V2.91675H7.58464V6.41675H11.0846V7.58341H7.58464V11.0834H6.41797V7.58341Z" fill="#7E7E7E"></path>
</svg>Add
</button>
</div>

</div>
            </div>

              </div>
              <!-- third step end -->


            </div>
          </div>

        </div>
      </div>
      <!-- Container-fluid end-->
    </div>
  </div>
</div> 

<script>
    document.getElementById('hideform').addEventListener('click', function() {
        // Show the table body
        document.getElementById('hidetb').style.display = 'none';
    
    // Show the button with id 'add_more'
    document.getElementById('add_more').style.display = 'flex';
    });
</script>
<script>
  document.getElementById('add_more').addEventListener('click', function() {
    document.getElementById('add_more').style.display = 'none';
        // Show the table body
        document.getElementById('hidetb').style.display = 'table';
    
    // Show the button with id 'add_more'
   
    });
</script>
<style>
  .welcome_volt_round_third .tabs_col_head {
    justify-content: end;
    margin: 20px 0px 0px;
}

.welcome_volt_round_third .tabs_col_head #add_more {
    background: #E6EBF6;
    text-align: center;
    color: #7E7E7E;
    font-size: 15px;
    font-weight: 500;
    letter-spacing: -0.02em;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: auto;
    padding: 10px 20px;
    border: 0;
}

.welcome_volt_round_third .tabs_col_head #add_more svg {
    width: 20px;
    height: 20px;
    margin: 0px 5px 0px 0px;
}
.welcome_volt_round_third td a {
    font-size: 12px; 
    color: #000;
}
.dark-only .welcome_volt_round_third td a {
    color: #FFF;
}
thead.dispnone {
    display: none;
}
.alert{
    margin-top: 20px;
    text-align: center;
}
  </style>
  <script>
  $(document).ready(function() {
    // Function to fetch and update table data
    function refreshTableData() {
      $.ajax({
        url: '{{ route("fetchDocuments") }}', // Replace with your route for refreshing table data
        method: 'GET',
        success: function(response) {
          // Update the table body with the fetched data
          $('#document-table-body').html(response);
        }
      });
    }

    // Call refreshTableData function every half second
    setInterval(refreshTableData, 50000000);
  });
</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-..." crossorigin="anonymous" />

@endsection